for (let i=0; i<20; i++)
    console.log('Kocham JS');

for (let i=0; i<20; i++)
    document.write('<br>Kocham JS');

// Komentarz liniowy

/*
Komentarz blokowy
 */