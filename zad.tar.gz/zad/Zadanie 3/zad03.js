var imie = prompt("Podaj imię");
document.write("Twoje imię: "+imie);

function myFunction() {
    alert("Kliknąłeś na mnie");
}
