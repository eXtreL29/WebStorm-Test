var J = "siemanko"; // Słowo var jest zmianą kosmetyczną, tzw. lukrem składniowym.
let txt="czesc";
txt="siemanko"

console.log(txt);
alert(txt);
document.write(txt);



const min = 1;
const max = 5000;
const random = Math.floor(Math.random()*(max-min+1)+min);
console.log(random);

console.log(random);
alert(random);
document.write(random);